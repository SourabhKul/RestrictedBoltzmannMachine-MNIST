import numpy as np
import rbm 
import util
import matplotlib.pyplot as plt

#Load data
global Xtrain, Xtest
Xtrain = np.load("../data/Xtrain.npy")
Xtest  = np.load("../data/Xtest.npy")

'''
#Show data
plt.figure(1)
util.plot_im_array2(Xtrain,28,100,10,"Training Sample")
plt.figure(2)
util.plot_im_array2(Xtest,28,100,10,"Test Sample")
plt.show()
'''
#Load parameters
global WP, WB, WC, d, k
WP = np.load("../models/MNISTWP.npy")
WB = np.load("../models/MNISTWB.npy")
WC = np.load("../models/MNISTWC.npy")
d = len(WC[0])
k = len(WB[0])
#Create RBM
mnistRBM  = rbm.rbm()
mnistRBM.set_params(WP,WB,WC)

#Number of Iterations
iterations = 500
num_chains = 100
#Gibbs sampler with single chain

x_samples, energies, _ = mnistRBM.single_gibbs_sampler(X=Xtrain[0], iterations=iterations, WP=WP, WB=WB, WC=WC)

#Q3.1
plt.figure(1)
util.plot_im_array2(x_samples[-100:],28,100,10,"Test Sample")
plt.savefig('../figures/3_1.png')
#Q3.2
plt.figure(2)
plt.plot(energies)
plt.ylabel('Energy')
plt.xlabel('Sample No.')
plt.savefig('../figures/3_2.png')
#plt.show()

#Create multiple gibbs sampler chains
aggregate_x_samples = np.empty([num_chains, iterations, len(WC[0])])
aggregate_energies = np.empty([num_chains, iterations])
for chain in range(num_chains):
    x_samples, energies, _ = mnistRBM.single_gibbs_sampler(X=Xtrain[chain], iterations=iterations, WP=WP, WB=WB, WC=WC)
    aggregate_x_samples[chain] = x_samples
    aggregate_energies[chain] = energies

#Q4.1 
plt.figure(3)
util.plot_im_array2(Xtrain,28,100,10,"Original Images")
plt.figure(4)
util.plot_im_array2(aggregate_x_samples[:,-1],28,100,10,"Sampled Images")
plt.savefig('../figures/4_1.png')
#plt.show()

#Q4.2
plt.figure(5)
plt.plot(range(iterations), aggregate_energies[0,:], 'r', range(iterations), aggregate_energies[1,:], 'g', range(iterations), aggregate_energies[2,:],'b', range(iterations),aggregate_energies[3,:],'purple', range(iterations),aggregate_energies[4,:],'y')
plt.ylabel('Energy')
plt.savefig('../figures/4_2.png')
#plt.show()

mnistRBM.fit(X=Xtrain, K = 400)
print 'fitting done'

iterations = 500
num_chains = 100

#Create multiple gibbs sampler chains
aggregate_x_samples = np.empty([num_chains, iterations, len(WC[0])])
aggregate_energies = np.empty([num_chains, iterations])
aggregate_pxgh = np.empty([num_chains, iterations, len(WC[0])])

for chain in range(num_chains):
    x_samples, energies, pxgh = mnistRBM.single_gibbs_sampler(X=Xtrain[chain], iterations=iterations, WP=WP, WB=WB, WC=WC)
    aggregate_x_samples[chain] = x_samples
    aggregate_energies[chain] = energies
    aggregate_pxgh[chain] = pxgh
#Q6.1 
plt.figure(6)
util.plot_im_array2(Xtrain,28,100,10,"Original Images")
plt.figure(7)
util.plot_im_array2(aggregate_x_samples[:,-1],28,100,10,"Sampled Images")
plt.savefig('../figures/6_1.png')
#plt.show()

#Q6.2
plt.figure(8)
util.plot_im_array2(aggregate_pxgh[:,-1],28,100,10,"Probabilites as images")
plt.ylabel('Energy')
plt.savefig('../figures/6_2.png')
#plt.show()